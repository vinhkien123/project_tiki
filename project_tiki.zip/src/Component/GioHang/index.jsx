import React, { Component } from 'react';

class index extends Component {
    render() {
        return (
            <div className="gioHang container my-5">
                <h2 className="title"> Giỏ hàng <span>(0 Sản phẩm)</span></h2>
            </div>
        );
    }
}

export default index;