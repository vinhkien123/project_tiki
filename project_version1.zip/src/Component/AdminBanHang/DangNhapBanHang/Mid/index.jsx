import React, { Component } from 'react';
import style from '../Mid/css.module.css'
import { connect } from 'react-redux'

import axios from 'axios'
class index extends Component {
    constructor(props) {
        super(props)
        this.state = {
            taiKhoan: "",
            matKhau: ""
        }
    }

    onChange = (e) => {

        this.setState({
            [e.target.name]: e.target.value
        })
    }
    onClick = (e) => {
        e.preventDefault();
        const data = {
            taiKhoan: this.state.taiKhoan,
            matKhau: this.state.matKhau
        }

     

    }
    render() {
        return (
            <div>

                <div className={style.mid}>
                    <h2 className={style.title}>Đăng nhập</h2>
                    <form action="" className={style.loginForm} style={{ background: "white" }}>
                        <div className="form-group">
                            <input type="text" name="taiKhoan" onChange={this.onChange} placeholder="Tài khoản Shop bán hàng, Email hoặc số điện thoại" className={style.form} />
                        </div>
                        <div className="form-group">
                            <input type="password" name="matKhau" onChange={this.onChange} placeholder="Mật khẩu" className={style.form} />
                        </div>
                        <div className="form-group">
                            <button className={style.btn} onClick={this.onClick}>Đăng nhập</button>
                        </div>
                        <div className={style.def}>
                            <p className={style.span}>Hoặc</p>
                        </div>
                        <div className="form-group">
                            <button style={{ background: "#282525", marginTop: "0px" }} className={style.btn}>Tạo tài khoản mới</button>
                        </div>
                    </form>
                    <div className="text-center mt-5">
                        <a href="#" style={{ fontSize: "12px" }} >Quên mật khẩu?</a>

                    </div>
                </div>

            </div >
        );
    }
}
const mapStateToProps = (state) => ({

})
export default connect(mapStateToProps)(index);