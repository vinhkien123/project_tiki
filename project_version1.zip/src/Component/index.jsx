import DanhSachSanPham from './DanhSachSanPham'
import React, { Component } from 'react';
import ThemSanPham from './Admin/Page/SanPham/ThemSanPham'
import { NavLink } from 'react-router-dom';
import TrangChu from './Screens/TrangChu';
import Slidebar from './Sidebar'
import ButtonXemThem from './ButtonXemThem';
class index extends Component {
    render() {
        return (
            <div>
                <TrangChu />
                
            </div>
        );
    }
}

export default index;       