// import React, { Component } from 'react'
// import { DangKy, DangNhap } from '../../Redux/Action/user';
// import { connect } from "react-redux"
// import SignUp from './DangKy'
// import Login from './DangNhap'
// class Example extends React.Component {
//     constructor(props) {
//         super(props)
//     }
//     componentDidMount() {

//     }




//     render() {
//         return (
//             <>

//                 {/* <!-- Button trigger modal --> */}



//                 <button type="button" className="item btn" data-toggle="modal" data-target="#exampleModal">
//                     <i className="icon-tracking"></i>
//                                 Đăng nhập <br></br>
//                                 tài khoản
//                      </button>
//                 {/* Modal */}
//                 <div className="modal fade" id="exampleModal" tabIndex={1} aria-labelledby="exampleModalLabel" aria-hidden="true">
//                     <div className="modal-dialog">
//                         <div className="modal-content">
//                             <div className="modal-header header-modal__form">
//                                 <ul className="nav nav-pills" id="pills-tab" role="tablist">
//                                     <li className="nav-item" role="presentation">
//                                         <a className="nav-link active" id="pills-home-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="pills-home" aria-selected="true">Đăng nhập</a>
//                                     </li>
//                                     <li className="nav-item" role="presentation">
//                                         <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="pills-profile" aria-selected="false">Tạo tài khoản</a>
//                                     </li>
//                                 </ul>
//                                 <button type="button" className="close" data-dismiss="modal" aria-label="Close">
//                                     <span aria-hidden="true">×</span>
//                                 </button>
//                             </div>
//                             <div className="modal-body">
//                                 <div className="tab-content" id="pills-tabContent">
//                                     <>
//                                         <Login />
//                                         <SignUp />
//                                     </>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>

//             </>
//         );
//     }
// }
// const mapStateToProps = state => ({

// })
// export default connect(mapStateToProps)(Example)

import React, { Component } from 'react';

class index extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default index;