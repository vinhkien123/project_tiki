import React, { Component } from 'react';

class index extends Component {
    render() {
        return (
            <div className="my-5">
                <h1 className="text-center">404 - Không tìm thấy trang</h1>
            </div>
        );
    }
}

export default index;