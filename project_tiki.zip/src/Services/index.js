import Products from './products';
import moviesServices from './movie.js';
export const ProductsService = new Products();
export const MoviesServices = new moviesServices();