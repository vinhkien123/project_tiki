import React, { Component } from 'react';

class index extends Component {
    render() {
        return (
            ////// HEADER //////
            <section className="container-fuild header">
                {/* <div className="headerTop">
                    <div className="text-HeaderTop">
                        <a href="#">
                            <img src="https://salt.tikicdn.com/ts/upload/42/f9/5e/7ccf8b09de0e051cc9054bd535f7b1a1.png" width={18} style={{ marginRight: 4 }} />
                            Ticketbox
                            </a>
                        <a href="#">
                            <img src="https://salt.tikicdn.com/media/upload/2019/01/30/736dfae48db88034a73e7fdb7f72756b.png" width={18} style={{ marginRight: 4 }} />
                            Trợ lý Tiki
                            </a>
                    </div>
                </div> */}
                
            </section>
        );
    }
}

export default index;