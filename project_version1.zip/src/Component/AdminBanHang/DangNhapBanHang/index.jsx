import React, { Component } from 'react';
import Header from './Header'
import Mid from './Mid'
import style from './Mid/css.module.css'
import { Spin, Switch, Alert } from 'antd';
import {connect} from 'react-redux';

class index extends Component {

   
    render() {
        return (
            <div className={style.bg}>
                    <Header />
                    <Mid />
            </div>
        );
    }
}

const mapStateToProps = state =>({
    loading : state.adminBanHangReducers?.loading
})
export default connect(mapStateToProps) (index);