import React, { Component, useState, useEffect } from 'react';
import { connect } from 'react-redux'
import '../../Sass/main.scss'
import { DanhSachSanPham, ThemSanPham } from '../../Redux/Action/product';
import { Link, NavLink } from 'react-router-dom';
import { Fade } from "react-awesome-reveal";


class index extends Component {

    componentDidMount() {

        console.log();
    }

    onClickSave = (sanPham) => {
        let array, flag
        ///// Kiểm tra có chuỗi JSON sản phẩm không
        if (localStorage.getItem('sanPham')) {
            // chuyển từ chuỗi JSON sang array chứa object sản phẩm
            array = JSON.parse(localStorage.getItem('sanPham'))
            /////Kiểm tra những sản phẩm có trong array hay không
            flag = true
            for (let i = 0; i < array.length; i++) {
                if (sanPham._id == array[i]._id) {
                    flag = false
                }
            }
            //// Nếu không bằng sẽ thêm vào array
            if (flag == true) {
                // thêm vô 1 object sản phẩm vào array chứa object sản phẩm
                array.push(sanPham)
            }

            /////// chuyển từ array sang chuỗi json =>>> đưa chuỗi json lên localStorage 
            localStorage.setItem('sanPham', JSON.stringify(array))
        }
        ///// Nếu không có thì tạo 1 cái array mới
        else {
            array = []
            array.push(sanPham)
            localStorage.setItem('sanPham', JSON.stringify(array))

        }
        // setTimeout(() => {
        //     window.location.reload(false);
        // }, 1)
        setTimeout(() => {
            localStorage.removeItem('sanPham')
        }, 1800)

    }

    renderDanhSachSanPham = (item, index) => {
        const giaSanPham = item.Price?.toString().replace(/(?<=\d)(?=(\d\d\d)+(?!\d))/g, ",")

        return (
            <a onClick={() => this.onClickSave(item)} href={`/chitietsanpham/${item._id}`} className="col-12 col-md-6 col-lg-3 card-tiki" key={index}>
                <div className="card text-left" >
                    <img className="card-img-top" src={item.ImageList[0]} alt />
                    <div className="card-body">

                        <h4 className="card-title">{item.Name?.length > 44 ? item.Name?.slice(0, 44) + "...." : item.Name}</h4>
                        <p className="card-text text-danger gia-hover">{giaSanPham}&nbsp; ₫</p>

                        <button className="btn btn-success">Mua sản phẩm</button>
                        {/* <Time /> */}

                    </div>
                </div>

            </a>
        )
    }
    render() {
        console.log("phantrang", this.props.danhSachSanPhamPhanTrang);
        console.log("danhsachneban", this.props.danhSachSanPham);
        const danhSach = this.props.danhSachSanPham.filter(item => item.StatusSale == false)
        const danhSachPhanTrang = this.props.danhSachSanPhamPhanTrang.filter(item => item.StatusSale == false)
        const danhSachSanPhamPhanTrang = danhSachPhanTrang.map((item, index) => {
            return (

                this.renderDanhSachSanPham(item, index)

            )
        })
        const danhSachSanPham = danhSach.map((item, index) => {
            return (

                this.renderDanhSachSanPham(item, index)

            )
        })
        let softPrice, sreachPrice, sreachKeyWord, renderKeyWord, sreachTheoDanhMuc;

        // softPrice = this.props.sreachPrice.sort((a, b) => {
        //     return a.giaSanPham - b.giaSanPham;
        // })
        // sreachPrice = this.props.sreachPrice.map((item, index) => {
        //     return (
        //         this.renderDanhSachSanPham(item, index)
        //     )
        // })
        console.log("???????", this.props.sreachProductApi);
        sreachKeyWord = this.props.sreachProductApi?.map((item, index) => {
            return (
                this.renderDanhSachSanPham(item, index)
            )
        })
        ///// Tìm kiếm trên client
        // danhSach.filter(
        //     ///////// Sreach chữ viết hoa và thường
        //     item => item.Name.toLowerCase().indexOf(this.props.keyWord) != -1
        // )
        // renderKeyWord = sreachKeyWord.map((item, index) => {
        //     return (
        //         this.renderDanhSachSanPham(item, index)
        //     )
        // })
        console.log("steachdanhmuc", this.props);
        sreachTheoDanhMuc = this.props.sreachTheoDanhMuc?.map((item, index) => {
            return (
                this.renderDanhSachSanPham(item, index)
            )
        })
        let render, sanPhamSreach
        // if (this.props.sreachPrice.length >= 1) {
        //     //// render khi người dùng sreach giá từ a -> b
        //     render = sreachPrice
        // } else if (this.props.sreachPrice.length <= 0) {
        //     //// render khi không có yêu cầu gì 
        //     render = danhSachSanPham
        // }
        if (this.props.statusShow == true) {
            let sanPham = JSON.parse(localStorage.getItem('sanPham'))
            render = sanPham.map((item, index) => {
                return this.renderDanhSachSanPham(item, index)
            })
        }
        else {
            render = danhSachSanPham

        }
        if (this.props.keyWordPage) {
            sanPhamSreach = sreachKeyWord
        } else if (this.props.sreachTheoDanhMuc) {
            sanPhamSreach = sreachTheoDanhMuc
        }

        return (
            <>
                {this.props.status == true ? sanPhamSreach : render}
            </>
        );
    }
}


const mapStateToProps = state => ({
    danhSachSanPham: state.productReducers.danhSachSanPham,
    danhSachSanPhamPhanTrang: state.productReducers.danhSachSanPhamPhanTrang,
    sreachAz: state.productReducers.sreachAz,
    sreachZa: state.productReducers.sreachZa,
    sreachPrice: state.productReducers.sreachPrice,
    keyWord: state.productReducers.keyWord
})
export default connect(mapStateToProps)(index);