import React, { Component } from 'react';
import { Menu } from 'antd';

class index extends Component {
    render() {
        const elementList = this.props.ListSubCategory.map((item, index) => {
            return (
                <li className="ant-menu-item ant-menu-item-only-child" key="9">
                    {item.Title}
                </li>

            )
        })
        return (
            <>
                {elementList}
            </>
        );
    }
}

export default index;