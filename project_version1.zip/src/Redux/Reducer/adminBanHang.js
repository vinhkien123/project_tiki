import { TEST } from "../Action/type"


const initialState = {
    loading:false,

}
const adminBanHangReducers = (state = initialState , action)=>{
    switch(action.type){
        case TEST:
            state.loading = action.payload
            return {...state}
        default : 
            return {...state}
    }
}
export default adminBanHangReducers