import React, { Component } from 'react';
class index extends Component {
    render() {
        return (
            <div className="container-fuild py-2 pr-3" style={{background:"white"}}>
                <div className="select" style={{position:"relative"}}>
                    <select name="" className=""  style={{position:"absolute",top:"0",right:"0"}} id="">
                        <option value="">Việt Nam - Tiếng Việt</option>
                    </select>
                </div>
                <h1 className="text-center">
                    <img src="" style={{ verticalAlign: "middle", height: "35px;" }} alt="" />
                </h1>

                
            </div>
        );
    }
}

export default index;